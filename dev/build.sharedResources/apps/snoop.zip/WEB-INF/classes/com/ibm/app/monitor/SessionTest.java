/** Reconstructed com.ibm.app.monitor.SessionTest.java
 * Decompilation showed that the existing version was a near-empty servlet. 
 */
package com.ibm.app.monitor;

import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * @author keshlam
 *
 */
public class SessionTest extends HttpServlet {
	public SessionTest()
	{
		super();
	}
	
	protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException
	{
		PrintWriter pw=response.getWriter();
		pw.print("Creating a Session");
		HttpSession session=request.getSession();
		pw.print("Session created");		
	}

	protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException
	{
		// This was a no-op in the existing SessionTest.
		// Probably shouldn't be.
		PrintWriter pw=response.getWriter();
		pw.print("Post: Creating a Session");
		HttpSession session=request.getSession();
		pw.print("Session created");		
	}
}
