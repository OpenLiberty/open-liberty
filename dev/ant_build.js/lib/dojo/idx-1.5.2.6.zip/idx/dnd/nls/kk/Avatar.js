define({     
//begin v1.x content
	copyText: "${num} элементтерін көшіру",
	moveText: "${num} элементтерін жылжыту",
	copyOneText: "1 элементті көшіру",
	moveOneText: "1 элементті жылжыту"
//end v1.x content
});

