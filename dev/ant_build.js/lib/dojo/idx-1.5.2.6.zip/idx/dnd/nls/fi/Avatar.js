define({     
//begin v1.x content
	copyText: "Kopioi ${num} kohdetta",
	moveText: "Siirrä ${num} kohdetta",
	copyOneText: "Kopioi 1 kohde",
	moveOneText: "Siirrä 1 kohde"
//end v1.x content
});

