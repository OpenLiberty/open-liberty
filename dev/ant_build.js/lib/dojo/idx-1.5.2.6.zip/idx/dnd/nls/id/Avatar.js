define({     
//begin v1.x content
	copyText: "Salin ${num} item",
	moveText: "Pindahkan ${num} item",
	copyOneText: "Salin 1 item",
	moveOneText: "Pindahkan 1 item"
//end v1.x content
});

