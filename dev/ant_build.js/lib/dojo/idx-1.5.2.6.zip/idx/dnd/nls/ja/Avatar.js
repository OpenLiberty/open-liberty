define({     
//begin v1.x content
	copyText: "${num} 項目コピー",
	moveText: "${num} 項目移動",
	copyOneText: "1 項目コピー",
	moveOneText: "1 項目移動"
//end v1.x content
});

