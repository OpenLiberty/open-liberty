define({     
//begin v1.x content
	copyText: "Αντιγραφή ${num} στοιχείων",
	moveText: "Μεταφορά ${num} στοιχείων",
	copyOneText: "Αντιγραφή 1 στοιχείου",
	moveOneText: "Μεταφορά 1 στοιχείου"
//end v1.x content
});

