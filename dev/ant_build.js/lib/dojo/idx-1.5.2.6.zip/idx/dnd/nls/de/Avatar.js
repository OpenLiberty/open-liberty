define({     
//begin v1.x content
	copyText: "${num} Elemente kopieren",
	moveText: "${num} Elemente verschieben",
	copyOneText: "1 Element kopieren",
	moveOneText: "1 verschieben"
//end v1.x content
});

