define({     
//begin v1.x content
	copyText: "نسخ ${num} من البنود",
	moveText: "نقل ${num} من البنود",
	copyOneText: "نسخ 1 بند",
	moveOneText: "نقل 1 بند"
//end v1.x content
});

