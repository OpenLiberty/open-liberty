define({     
//begin v1.x content
	copyText: "Kopiraj št. elementov: ${num}",
	moveText: "Premakni št. elementov: ${num}",
	copyOneText: "Kopiraj 1 element",
	moveOneText: "Premakni 1 element"
//end v1.x content
});

