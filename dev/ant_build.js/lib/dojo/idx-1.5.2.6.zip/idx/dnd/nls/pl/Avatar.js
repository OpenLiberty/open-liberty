define({     
//begin v1.x content
	copyText: "Kopiuj elementów: ${num}",
	moveText: "Przenieś elementów: ${num}",
	copyOneText: "Kopiuj 1 element",
	moveOneText: "Przenieś 1 element"
//end v1.x content
});

