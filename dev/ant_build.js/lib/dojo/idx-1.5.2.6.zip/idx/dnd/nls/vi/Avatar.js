define({     
//begin v1.x content
	copyText: "Sao chép ${num} mục",
	moveText: "Chuyển ${num} mục",
	copyOneText: "Sao chép 1 mục",
	moveOneText: "Chuyển 1 mục"
//end v1.x content
});

