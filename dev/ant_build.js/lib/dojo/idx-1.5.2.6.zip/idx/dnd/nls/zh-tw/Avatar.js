define({     
//begin v1.x content
	copyText: "複製 ${num} 個項目",
	moveText: "移動 ${num} 個項目",
	copyOneText: "複製 1 個項目",
	moveOneText: "移動 1 個項目"
//end v1.x content
});

