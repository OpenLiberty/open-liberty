define({     
//begin v1.x content
	copyText: "Копіювати ${num} елементи(ів)",
	moveText: "Перемістити ${num} елементи(ів)",
	copyOneText: "Копіювати 1 елемент",
	moveOneText: "Перемістити 1 елемент"
//end v1.x content
});

