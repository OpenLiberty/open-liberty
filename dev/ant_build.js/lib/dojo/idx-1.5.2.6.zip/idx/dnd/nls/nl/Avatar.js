define({     
//begin v1.x content
	copyText: "${num} items kopiëren",
	moveText: "${num} items verplaatsen",
	copyOneText: "1 item kopiëren",
	moveOneText: "1 item verplaatsen"
//end v1.x content
});

