define({     
//begin v1.x content
   	altTitle: "Pestanya de l'espai de treball per a ${title}"
//end v1.x content
});

