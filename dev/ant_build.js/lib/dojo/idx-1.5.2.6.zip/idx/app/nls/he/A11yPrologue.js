define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT עם ${accessKey}",
	keySequence_Firefox: "ALT עם SHIFT עם ${accessKey} במערכות Windows ו-Linux או CONTROL עם ${accessKey} במערכות Mac",
	keySequence_Safari: "CONTROL עם OPT עם ${accessKey} במערכות Mac או ALT עם ${accessKey} במערכות Windows",
	keySequence_Chrome: "ALT עם עם ${accessKey} במערכות Windows ו-Linux או CONTROL עם OPT עם ${accessKey} במערכות Mac",
	shortcutListMessage: "קיצורי הדרך עבור דף זה הם:",
	a11yPrologueLabel: "מבוא לנגישות",
    a11yStatementLabel: "הצהרת נגישות",
    skipToLocationMessage: "דילוג אל ${description}",
	shortcutKeyMessage_internal: "כדי לדלג אל ${description} לחצו על ${keySequence}.",
	shortcutKeyMessage_external: "כדי לקשר אל ${description} לחצו על ${keySequence}.",
	shortcutMessage_internal: "דילוג אל ${description}.",
	shortcutMessage_external: "קישור אל ${description}.",

	a11yMainContentAreaName: "תוכן עיקרי",

	a11yNavigationAreaName: "ניווט",

	a11yBannerAreaName: "כרזה"
//end v1.x content
});

