define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Kan ikke åbne mere end ${maxOpen} \"${workspaceTypeName}\"\u200e-arbejdsområder. Hvis det er muligt, skal du lukke de \"${workspaceTypeName}\"\u200e-arbejdsområder, der allerede er åbne."
//end v1.x content
});

