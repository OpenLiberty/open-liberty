define({     
//begin v1.x content
   	altTitle: "Καρτέλα χώρου εργασίας για: ${title}"
//end v1.x content
});

