define({     
//begin v1.x content
	about:				"Informazioni su",
	help:			      "Guida",
	logout:				"Disconnetti ",
	login:				"Collega",
	userNameMessage:  "Benvenuto ${username}"
//end v1.x content
});

