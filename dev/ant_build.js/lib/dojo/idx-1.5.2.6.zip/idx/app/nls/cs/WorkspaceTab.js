define({     
//begin v1.x content
   	altTitle: "Karta Pracovní prostor pro položku ${title}"
//end v1.x content
});

