define({     
//begin v1.x content
    loadingMessage: "A carregar ${workspaceTitle}.  Aguarde....",
    failedLoadMessage: "Falha ao carregar ${workspaceTitle}."
//end v1.x content
});

