define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Er kunnen niet meer dan ${maxOpen} \"${workspaceTypeName}\"\u200e werkgebieden geopend worden.  Sluit indien mogelijk \"${workspaceTypeName}\"\u200e werkgebieden die open staan."
//end v1.x content
});

