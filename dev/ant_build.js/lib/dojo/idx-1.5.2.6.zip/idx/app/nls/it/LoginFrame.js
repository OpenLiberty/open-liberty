define({     
//begin v1.x content
	loginTitle: "Accesso",
	labelUserName: "Nome utente",
	labelPassword: "Password",
	invalidMessageTitle: "Tentativo di accesso non valido",
	invalidMessage: "Non sono stati immessi valori validi in entrambi i campi obbligatori. "
//end v1.x content
});

