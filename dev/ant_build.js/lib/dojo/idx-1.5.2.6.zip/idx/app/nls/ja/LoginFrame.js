define({     
//begin v1.x content
	loginTitle: "ログイン",
	labelUserName: "ユーザー名",
	labelPassword: "パスワード",
	invalidMessageTitle: "無効なログインの試行",
	invalidMessage: "両方の必須フィールドに有効な値が入力されていません。"
//end v1.x content
});

