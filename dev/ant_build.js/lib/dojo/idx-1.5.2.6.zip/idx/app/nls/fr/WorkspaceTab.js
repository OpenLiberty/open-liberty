define({     
//begin v1.x content
   	altTitle: "Onglet Espace de travail pour ${title}"
//end v1.x content
});

