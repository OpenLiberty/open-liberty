define({     
//begin v1.x content
    loadingMessage: "Қотарылуда ${workspaceTitle}.  Күте тұрыңыз....",
    failedLoadMessage: "Қотару кезінде қате пайда болды ${workspaceTitle}."
//end v1.x content
});

