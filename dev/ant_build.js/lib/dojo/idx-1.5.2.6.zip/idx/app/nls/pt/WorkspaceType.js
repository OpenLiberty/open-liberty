define({     
//begin v1.x content
    loadingMessage: "Carregando ${workspaceTitle}.  Aguarde...",
    failedLoadMessage: "Falha ao carregar ${workspaceTitle}."
//end v1.x content
});

