define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT плюс ${accessKey}",
	keySequence_Firefox: "ALT плюс SHIFT плюс ${accessKey} на Windows и Linux или CONTROL плюс ${accessKey} на Mac",
	keySequence_Safari: "CONTROL плюс OPT плюс ${accessKey} на Mac или ALT плюс ${accessKey} на Windows",
	keySequence_Chrome: "ALT плюс ${accessKey} на Windows и Linux или CONTROL плюс OPT плюс ${accessKey} на Mac",
	shortcutListMessage: "Преките пътища за тази страница са:",
	a11yPrologueLabel: "Начало за достъпност",
    a11yStatementLabel: "Израз за достъпност",
    skipToLocationMessage: "Пропускане до ${description}",
	shortcutKeyMessage_internal: "За пропускане до ${description}, използвайте ${keySequence}.",
	shortcutKeyMessage_external: "За свързване на ${description}, използвайте ${keySequence}.",
	shortcutMessage_internal: "Пропускане до ${description}.",
	shortcutMessage_external: "Свързване до ${description}.",

	a11yMainContentAreaName: "основно съдържание",

	a11yNavigationAreaName: "навигация",

	a11yBannerAreaName: "банер"
//end v1.x content
});

