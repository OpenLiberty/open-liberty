define({     
//begin v1.x content
    tooManyOpenWorkspaces: "لا يمكن فتح أكثر من ${maxOpen} \"${workspaceTypeName}\"\u200e مساحة عمل.  ان أمكن، قم باغلاق مساحات عمل  \"${workspaceTypeName}\"\u200e التي تم فتحها بالفعل."
//end v1.x content
});

