/*
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2012 All Rights Reserved
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define({      
//begin v1.x content
	ibmlogo: "IBM&reg;",
	actionShare: "共享",
	actionSettings: "设置",
	actionHelp: "帮助",
	searchEntry: "搜索",
	searchSubmit: "搜索",
	primarySearchLabelSuffix: "主要搜索",
	secondarySearchLabelSuffix: "辅助搜索",
	homeButton: "主页"
//end v1.x content
});

