define({     
//begin v1.x content
    loadingMessage: "Läser in ${workspaceTitle}. Vänta...",
    failedLoadMessage: "Det gick inte att läsa in ${workspaceTitle}."
//end v1.x content
});

