define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT + ${accessKey}",
	keySequence_Firefox: "ALT + SHIFT + ${accessKey} v systémoch Windows a Linux alebo CONTROL + ${accessKey} v systémoch Mac",
	keySequence_Safari: "CONTROL + OPT + ${accessKey} v systémoch Mac alebo ALT 9 ${accessKey} v systémoch Windows",
	keySequence_Chrome: "ALT + ${accessKey} v systémoch Windows a Linux alebo CONTROL + OPT + ${accessKey} v systémoch Mac",
	shortcutListMessage: "Klávesové skratky pre túto stránku sú:",
	a11yPrologueLabel: "Úvod do zjednodušenia ovládania",
    a11yStatementLabel: "Vyhlásenie o zjednodušení ovládania",
    skipToLocationMessage: "Preskočiť na ${description}",
	shortcutKeyMessage_internal: "Ak chcete preskočiť na ${description}, použite ${keySequence}.",
	shortcutKeyMessage_external: "Ak chcete vytvoriť prepojenie na ${description}, použite ${keySequence}.",
	shortcutMessage_internal: "Preskočiť na ${description}.",
	shortcutMessage_external: "Prepojenie na ${description}.",

	a11yMainContentAreaName: "main content",

	a11yNavigationAreaName: "navigation",

	a11yBannerAreaName: "banner"
//end v1.x content
});

