define({     
//begin v1.x content
    loadingMessage: "Завантаження ${workspaceTitle}.  Зачекайте....",
    failedLoadMessage: "Не вдалося завантажити ${workspaceTitle}."
//end v1.x content
});

