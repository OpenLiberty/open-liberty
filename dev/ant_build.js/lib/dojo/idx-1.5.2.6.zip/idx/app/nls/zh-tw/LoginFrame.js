define({     
//begin v1.x content
	loginTitle: "登入",
	labelUserName: "使用者名稱",
	labelPassword: "密碼",
	invalidMessageTitle: "無效的登入嘗試",
	invalidMessage: "兩個必要欄位均未輸入有效的值。"
//end v1.x content
});

