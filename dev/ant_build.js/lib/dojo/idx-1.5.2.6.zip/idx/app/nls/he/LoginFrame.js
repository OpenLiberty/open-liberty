define({     
//begin v1.x content
	loginTitle: "התחברות",
	labelUserName: "שם משתמש",
	labelPassword: "סיסמה",
	invalidMessageTitle: "נסיון התחברות לא חוקי ",
	invalidMessage: "לא צוין ערך חוקי בשני השדות הדרושים. "
//end v1.x content
});

