define({     
//begin v1.x content
	about:				"Thông tin",
	help:			      "Trợ giúp",
	logout:				"Ðăng xuất",
	login:				"Ðăng nhập",
	userNameMessage:  "Chào mừng ${username}"
//end v1.x content
});

