define({     
//begin v1.x content
    loadingMessage: "Încărcare ${workspaceTitle}.  Vă rugăm să aşteptaţi....",
    failedLoadMessage: "A eşuat încărcarea ${workspaceTitle}."
//end v1.x content
});

