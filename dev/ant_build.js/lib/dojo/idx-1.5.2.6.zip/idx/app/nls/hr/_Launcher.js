define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Ne može se otvoriti više od ${maxOpen} \"${workspaceTypeName}\"\u200e radnih prostora.  Ako je moguće, zatvorite \"${workspaceTypeName}\"\u200e radne prostore koji su već otvoreni."
//end v1.x content
});

