define({     
//begin v1.x content
    tooManyOpenWorkspaces: "No es poden obrir més de ${maxOpen}  espais de treball \"${workspaceTypeName}\"\u200e. Si és possible, tanqueu els espais de treball \"${workspaceTypeName}\"\u200e que ja hi ha oberts."
//end v1.x content
});

