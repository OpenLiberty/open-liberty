define({     
//begin v1.x content
	about:				"Om",
	help:			      "Hjälp",
	logout:				"Logga ut",
	login:				"Logga in",
	userNameMessage:  "Välkommen ${username}"
//end v1.x content
});

