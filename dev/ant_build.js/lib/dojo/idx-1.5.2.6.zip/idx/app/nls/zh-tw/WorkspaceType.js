define({     
//begin v1.x content
    loadingMessage: "正在載入 ${workspaceTitle}。請稍後....",
    failedLoadMessage: "無法載入 ${workspaceTitle}。"
//end v1.x content
});

