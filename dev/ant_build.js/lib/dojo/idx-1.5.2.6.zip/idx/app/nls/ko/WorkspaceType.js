define({     
//begin v1.x content
    loadingMessage: "${workspaceTitle}을(를) 로드하는 중입니다. 기다리십시오...",
    failedLoadMessage: "${workspaceTitle} 로드에 실패했습니다."
//end v1.x content
});

