define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT artı ${accessKey}",
	keySequence_Firefox: "Windows ve Linux'ta ALT artı ÜST KARAKTER artı ${accessKey} ya da Mac'te CONTROL artı ${accessKey}",
	keySequence_Safari: "Mac'ta CONTROL artı OPT artı ${accessKey} ya da Windows'ta ALT artı ${accessKey}",
	keySequence_Chrome: "Windows ve Linux'ta ALT artı ${accessKey} ya da Mac'te CONTROL artı OPT artı ${accessKey}",
	shortcutListMessage: "Bu sayfanın kısayolları şunlardır:",
	a11yPrologueLabel: "Erişilirlik Öndeyişi",
    a11yStatementLabel: "Erişilirlik Bildirimi",
    skipToLocationMessage: "${description} görünümüne atla",
	shortcutKeyMessage_internal: "${description} görünümüne atlamak için ${keySequence} tuşunu (tuşlarını) kullanın.",
	shortcutKeyMessage_external: "${description} öğesine bağlantı oluşturmak için ${keySequence}  tuşunu (tuşlarını) kullanın.",
	shortcutMessage_internal: "${description} görünümüne atla.",
	shortcutMessage_external: "${description} öğesine bağlantı oluştur.",

	a11yMainContentAreaName: "ana içerik",

	a11yNavigationAreaName: "dolaşma",

	a11yBannerAreaName: "büyük başlık"
//end v1.x content
});

