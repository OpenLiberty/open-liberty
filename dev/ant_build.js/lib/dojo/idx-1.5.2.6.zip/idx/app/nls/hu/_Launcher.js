define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Legfeljebb ${maxOpen} \"${workspaceTypeName}\"\u200e munkaterület nyitható meg.  Ha lehetséges, zárjon be nyitott \"${workspaceTypeName}\"\u200e munkaterületeket."
//end v1.x content
});

