define({     
//begin v1.x content
	loginTitle: "Logga in",
	labelUserName: "Användarnamn",
	labelPassword: "Lösenord",
	invalidMessageTitle: "Ogiltigt inloggningsförsök",
	invalidMessage: "Ett giltigt värde har inte angetts i båda fälten."
//end v1.x content
});

