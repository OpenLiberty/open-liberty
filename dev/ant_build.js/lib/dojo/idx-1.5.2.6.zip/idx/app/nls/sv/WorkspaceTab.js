define({     
//begin v1.x content
   	altTitle: "Arbetsutrymmesflik för ${title}"
//end v1.x content
});

