define({     
//begin v1.x content
    loadingMessage: "${workspaceTitle} yükleniyor.  Lütfen bekleyin....",
    failedLoadMessage: "${workspaceTitle} yüklenemedi."
//end v1.x content
});

