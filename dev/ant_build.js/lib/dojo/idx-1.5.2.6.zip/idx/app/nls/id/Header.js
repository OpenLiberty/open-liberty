/*
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2012 All Rights Reserved
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define({      
//begin v1.x content
	ibmlogo: "IBM&reg;",
	actionShare: "Bagikan",
	actionSettings: "Pengaturan",
	actionHelp: "Bantuan",
	searchEntry: "Pencarian",
	searchSubmit: "Cari",
	primarySearchLabelSuffix: "pencarian utama",
	secondarySearchLabelSuffix: "pencarian sekunder",
	homeButton: "Beranda"
//end v1.x content
});

