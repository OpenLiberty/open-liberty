define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Nemožno otvoriť viac ako ${maxOpen} pracovných priestorov \"${workspaceTypeName}\"\u200e.  Ak to je možné, zatvorte pracovné priestory \"${workspaceTypeName}\"\u200e, ktoré už sú otvorené."
//end v1.x content
});

