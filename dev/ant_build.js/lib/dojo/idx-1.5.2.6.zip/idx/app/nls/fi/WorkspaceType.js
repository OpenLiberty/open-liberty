define({     
//begin v1.x content
    loadingMessage: "Työtilan ${workspaceTitle} lataus on meneillään.  Odota...",
    failedLoadMessage: "Työtilan ${workspaceTitle} lataus ei onnistunut."
//end v1.x content
});

