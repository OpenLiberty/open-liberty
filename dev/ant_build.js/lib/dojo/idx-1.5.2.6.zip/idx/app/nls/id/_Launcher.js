define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Tidak dapat membuka lebih dari ${maxOpen} ruang kerja \"${workspaceTypeName}\"\u200e.  Jika memungkinkan, tutup ruang kerja \"${workspaceTypeName}\"\u200e yang sudah terbuka."
//end v1.x content
});

