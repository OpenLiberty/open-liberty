define({     
//begin v1.x content
   	altTitle: "Scheda aree di lavoro per ${title}"
//end v1.x content
});

