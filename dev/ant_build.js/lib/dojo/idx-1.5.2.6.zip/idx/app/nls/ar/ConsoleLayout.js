define({     
//begin v1.x content
	about:				"نبذة عن",
	help:			      "مساعدة",
	logout:				"انهاء الاتصال",
	login:				"بدء الاتصال",
	userNameMessage:  "مرحبا ${username}"
//end v1.x content
});

