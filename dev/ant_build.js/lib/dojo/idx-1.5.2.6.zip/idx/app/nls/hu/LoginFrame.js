define({     
//begin v1.x content
	loginTitle: "Bejelentkezés",
	labelUserName: "Felhasználónév",
	labelPassword: "Jelszó",
	invalidMessageTitle: "Érvénytelen bejelentkezési kísérlet",
	invalidMessage: "Nem adott meg érvényes értéket mindkét kötelező mezőben."
//end v1.x content
});

