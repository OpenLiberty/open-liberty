/*
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2012 All Rights Reserved
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define({      
//begin v1.x content
	ibmlogo: "IBM&reg;",
	actionShare: "공유",
	actionSettings: "설정",
	actionHelp: "도움말",
	searchEntry: "검색",
	searchSubmit: "검색",
	primarySearchLabelSuffix: "기본 검색",
	secondarySearchLabelSuffix: "보조 검색",
	homeButton: "홈"
//end v1.x content
});

