define({     
//begin v1.x content
    loadingMessage: "Indlæser ${workspaceTitle}. Vent....",
    failedLoadMessage: "Kan ikke indlæse ${workspaceTitle}."
//end v1.x content
});

