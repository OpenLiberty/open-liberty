define({     
//begin v1.x content
   	altTitle: "Työtilan välilehti - ${title}"
//end v1.x content
});

