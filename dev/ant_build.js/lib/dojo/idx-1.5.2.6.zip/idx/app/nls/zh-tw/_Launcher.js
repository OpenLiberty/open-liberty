define({     
//begin v1.x content
    tooManyOpenWorkspaces: "無法開啟超過 ${maxOpen} 個 \"${workspaceTypeName}\"\u200e 工作區。如果可能的話，請關閉已開啟的 \"${workspaceTypeName}\"\u200e 工作區。"
//end v1.x content
});

