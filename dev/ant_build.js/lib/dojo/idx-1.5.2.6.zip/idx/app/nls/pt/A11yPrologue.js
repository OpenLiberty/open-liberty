define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT com ${accessKey}",
	keySequence_Firefox: "ALT com SHIFT com ${accessKey} no Windows e Linux ou CONTROL com ${accessKey} no Mac",
	keySequence_Safari: "CONTROL com OPT com ${accessKey} no Mac ou ALT com ${accessKey} no Windows",
	keySequence_Chrome: "ALT com ${accessKey} no Windows e Linux ou CONTROL com OPT e ${accessKey} no Mac",
	shortcutListMessage: "Os atalhos para esta página são:",
	a11yPrologueLabel: "Prólogos de Acessibilidade",
    a11yStatementLabel: "Instrução de Acessibilidade",
    skipToLocationMessage: "Pular para o(a) ${description}",
	shortcutKeyMessage_internal: "Para pular para o(a) ${description} use ${keySequence}.",
	shortcutKeyMessage_external: "Para acessar o link de ${description} use ${keySequence}.",
	shortcutMessage_internal: "Pular para o(a) ${description}.",
	shortcutMessage_external: "Acessar link de ${description}.",

	a11yMainContentAreaName: "conteúdo principal",

	a11yNavigationAreaName: "Selecionar Idioma?",

	a11yBannerAreaName: "banner"
//end v1.x content
});

