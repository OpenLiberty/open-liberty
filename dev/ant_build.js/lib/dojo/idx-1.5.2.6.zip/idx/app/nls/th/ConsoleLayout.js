define({     
//begin v1.x content
	about:				"เกี่ยวกับ",
	help:			      "วิธีใช้",
	logout:				"ล็อกเอาต์",
	login:				"ล็อกอิน",
	userNameMessage:  "ขอต้อนรับ ${username}"
//end v1.x content
});

