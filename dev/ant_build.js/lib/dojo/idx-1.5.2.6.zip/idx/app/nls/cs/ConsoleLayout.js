define({     
//begin v1.x content
	about:				"O programu",
	help:			      "Nápověda",
	logout:				"Odhlásit se",
	login:				"Přihlásit se",
	userNameMessage:  "Vítejte, uživateli ${username}"
//end v1.x content
});

