define({     
//begin v1.x content
    tooManyOpenWorkspaces: "לא ניתן לפתוח יותר מ-${maxOpen} מרחבי עבודה מסוג \"${workspaceTypeName}\".‏ במידת האפשר, סגרו מרחבי עבודה מסוג \"${workspaceTypeName}\" שכבר פתוחים."
//end v1.x content
});

