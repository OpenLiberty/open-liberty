define({     
//begin v1.x content
	about:				"O",
	help:			      "Pomoć",
	logout:				"Odjava",
	login:				"Prijava",
	userNameMessage:  "Dobro došli, ${username}"
//end v1.x content
});

