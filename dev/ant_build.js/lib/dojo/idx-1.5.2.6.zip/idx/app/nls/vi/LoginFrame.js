define({     
//begin v1.x content
	loginTitle: "Ðăng nhập",
	labelUserName: "Tên người dùng",
	labelPassword: "Mật khẩu",
	invalidMessageTitle: "Thử đăng nhập không hợp lệ",
	invalidMessage: "Giá trị hợp lệ chưa được nhập vào cả hai trường yêu cầu."
//end v1.x content
});

