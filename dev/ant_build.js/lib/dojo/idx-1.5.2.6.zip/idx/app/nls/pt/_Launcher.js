define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Não é possível abrir mais de ${maxOpen} áreas de trabalho \"${workspaceTypeName}\"\u200e.  Se possível, feche as áreas de trabalho \"${workspaceTypeName}\"\u200e que já estão abertas."
//end v1.x content
});

