/*
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2012 All Rights Reserved
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define({      
//begin v1.x content
	ibmlogo: "IBM&reg;",
	actionShare: "Delen",
	actionSettings: "Instellingen",
	actionHelp: "Help",
	searchEntry: "Zoeken",
	searchSubmit: "Zoeken",
	primarySearchLabelSuffix: "primaire zoekopdracht",
	secondarySearchLabelSuffix: "secundaire zoekopdracht",
	homeButton: "Home"
//end v1.x content
});

