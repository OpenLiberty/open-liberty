define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Không thể mở hơn ${maxOpen} \"${workspaceTypeName}\"\u200e vùng làm việc.  Nếu có, đóng \"${workspaceTypeName}\"\u200e vùng làm việc đã được mở."
//end v1.x content
});

