define({     
//begin v1.x content
	loginTitle: "Prihlásiť",
	labelUserName: "Meno užívateľa",
	labelPassword: "Heslo",
	invalidMessageTitle: "Neplatný pokus o prihlásenie",
	invalidMessage: "V oboch povinných poliach nie je zadaná platná hodnota."
//end v1.x content
});

