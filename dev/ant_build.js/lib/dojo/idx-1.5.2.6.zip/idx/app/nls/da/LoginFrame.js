define({     
//begin v1.x content
	loginTitle: "Log på",
	labelUserName: "Brugernavn",
	labelPassword: "Kodeord",
	invalidMessageTitle: "Ugyldigt logonforsøg",
	invalidMessage: "Der er ikke angivet en gyldig værdi i begge de påkrævede felter."
//end v1.x content
});

