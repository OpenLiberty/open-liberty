define({     
//begin v1.x content
	loginTitle: "登录",
	labelUserName: "用户名",
	labelPassword: "密码",
	invalidMessageTitle: "无效的登录尝试",
	invalidMessage: "在两个必填字段中未输入有效的值。"
//end v1.x content
});

