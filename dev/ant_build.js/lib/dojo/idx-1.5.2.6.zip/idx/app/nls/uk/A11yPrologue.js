define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT + ${accessKey}",
	keySequence_Firefox: "ALT + SHIFT + ${accessKey} у Windows та Linux або CONTROL + ${accessKey} у Mac",
	keySequence_Safari: "CONTROL + OPT + ${accessKey} у Mac або ALT + ${accessKey} у Windows",
	keySequence_Chrome: "ALT + ${accessKey} у Windows та Linux або CONTROL + OPT + ${accessKey} у Mac",
	shortcutListMessage: "Гарячі клавіші для цієї сторінки:",
	a11yPrologueLabel: "Вступ до розділу Спеціальні можливості",
    a11yStatementLabel: "Блок спеціальних можливостей",
    skipToLocationMessage: "Перейти до: ${description}",
	shortcutKeyMessage_internal: "Для переходу до розділу ${description} використовуйте ${keySequence}.",
	shortcutKeyMessage_external: "Для посилання на розділ ${description} використовуйте ${keySequence}.",
	shortcutMessage_internal: "Перейти до ${description}.",
	shortcutMessage_external: "Посилання на ${description}.",

	a11yMainContentAreaName: "головні матеріали",

	a11yNavigationAreaName: "навігація",

	a11yBannerAreaName: "банер"
//end v1.x content
});

