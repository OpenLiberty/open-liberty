define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Nu se pot deschide mai multe spaţii de lucru decât ${maxOpen} \"${workspaceTypeName}\"\u200e.  Dacă este posibil, închideţi spaţiile de lucru \"${workspaceTypeName}\"\u200e care sunt deschise deja."
//end v1.x content
});

