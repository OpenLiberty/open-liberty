define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Нельзя открыть более ${maxOpen} рабочих пространств \"${workspaceTypeName}\"\u200e.  Если можно, закройте уже открытые рабочие пространства \"${workspaceTypeName}\"\u200e."
//end v1.x content
});

