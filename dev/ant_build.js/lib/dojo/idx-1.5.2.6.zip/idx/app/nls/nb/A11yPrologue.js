define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT pluss ${accessKey}",
	keySequence_Firefox: "ALT pluss SKIFT pluss ${accessKey} på Windows og Linux eller Ctrl pluss ${accessKey} på Mac",
	keySequence_Safari: "Ctrl pluss Tilvalgstast pluss ${accessKey} på Mac eller ALT pluss ${accessKey} på Windows",
	keySequence_Chrome: "ALT pluss ${accessKey} på Windows og Linux eller Ctrl pluss Tilvalgstast pluss ${accessKey} på Mac",
	shortcutListMessage: "Snarveiene for denne siden:",
	a11yPrologueLabel: "Prolog for tilgjengelighet",
    a11yStatementLabel: "Erklæring om tilgjengelighet",
    skipToLocationMessage: "Gå til ${description}",
	shortcutKeyMessage_internal: "For å gå til ${description} bruker du ${keySequence}.",
	shortcutKeyMessage_external: "For å linke til ${description} bruker du ${keySequence}.",
	shortcutMessage_internal: "Gå til ${description}.",
	shortcutMessage_external: "Link til ${description}.",

	a11yMainContentAreaName: "hovedinnhold",

	a11yNavigationAreaName: "navigering",

	a11yBannerAreaName: "banner"
//end v1.x content
});

