define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Lajin \"${workspaceTypeName}\"\u200e työtiloja voi avata enintään ${maxOpen}.  Sulje kaikki avoimet lajin \"${workspaceTypeName}\"\u200e työtilat, jos se on mahdollista."
//end v1.x content
});

