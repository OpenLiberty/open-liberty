define({     
//begin v1.x content
	about:				"Tietoja",
	help:			      "Ohje",
	logout:				"Kirjaudu ulos",
	login:				"Kirjaudu sisään",
	userNameMessage:  "Tervetuloa ${username}"
//end v1.x content
});

