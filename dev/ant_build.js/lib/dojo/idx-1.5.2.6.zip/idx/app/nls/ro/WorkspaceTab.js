define({     
//begin v1.x content
   	altTitle: "Fila spaţiu de lucru pentru ${title}"
//end v1.x content
});

