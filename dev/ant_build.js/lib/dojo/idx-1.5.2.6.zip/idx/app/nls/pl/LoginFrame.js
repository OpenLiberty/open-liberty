define({     
//begin v1.x content
	loginTitle: "Logowanie",
	labelUserName: "Nazwa użytkownika",
	labelPassword: "Hasło",
	invalidMessageTitle: "Niepoprawna próba logowania",
	invalidMessage: "Do żadnego z dwóch wymaganych pól nie wprowadzono poprawnej wartości."
//end v1.x content
});

