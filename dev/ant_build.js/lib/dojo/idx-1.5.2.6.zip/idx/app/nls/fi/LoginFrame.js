define({     
//begin v1.x content
	loginTitle: "Sisäänkirjaus",
	labelUserName: "Käyttäjätunnus",
	labelPassword: "Salasana",
	invalidMessageTitle: "Virheellinen sisäänkirjaus",
	invalidMessage: "Pakollisiin kenttiin ei ole annettu kelvollisia arvoja."
//end v1.x content
});

