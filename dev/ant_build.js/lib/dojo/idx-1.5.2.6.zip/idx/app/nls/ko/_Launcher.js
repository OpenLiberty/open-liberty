define({     
//begin v1.x content
    tooManyOpenWorkspaces: "${maxOpen}개를 초과하는 \"${workspaceTypeName}\"\u200e 작업영역을 열 수 없습니다. 가능하면 이미 열려 있는 \"${workspaceTypeName}\"\u200e 작업영역을 닫으십시오."
//end v1.x content
});

