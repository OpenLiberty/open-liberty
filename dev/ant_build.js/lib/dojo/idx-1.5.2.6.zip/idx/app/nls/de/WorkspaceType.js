define({     
//begin v1.x content
    loadingMessage: "${workspaceTitle} wird geladen. Bitte warten....",
    failedLoadMessage: "${workspaceTitle} konnte nicht geladen werden."
//end v1.x content
});

