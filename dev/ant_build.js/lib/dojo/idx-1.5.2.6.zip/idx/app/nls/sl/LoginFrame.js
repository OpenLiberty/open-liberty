define({     
//begin v1.x content
	loginTitle: "Prijava",
	labelUserName: "Uporabniško ime",
	labelPassword: "Geslo",
	invalidMessageTitle: "Neuspešna prijava",
	invalidMessage: "V obe zahtevani polji niste vnesli veljavnih vrednosti."
//end v1.x content
});

