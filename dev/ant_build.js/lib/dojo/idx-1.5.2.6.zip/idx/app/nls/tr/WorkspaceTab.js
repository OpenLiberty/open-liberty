define({     
//begin v1.x content
   	altTitle: "${title} İçin Çalışma Alanı Sekmesi"
//end v1.x content
});

