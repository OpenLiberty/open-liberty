define({     
//begin v1.x content
    tooManyOpenWorkspaces: "不能打开超过 ${maxOpen} 个 \"${workspaceTypeName}\"\u200e 工作空间。如果可能，请关闭已打开的 \"${workspaceTypeName}\"\u200e 工作空间。"
//end v1.x content
});

