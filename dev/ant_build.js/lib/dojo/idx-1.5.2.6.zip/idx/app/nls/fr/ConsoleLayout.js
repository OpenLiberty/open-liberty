define({     
//begin v1.x content
	about:				"A propos de",
	help:			      "Aide",
	logout:				"Fermer la session",
	login:				"Ouvrir une session",
	userNameMessage:  "Bienvenue ${username}"
//end v1.x content
});

