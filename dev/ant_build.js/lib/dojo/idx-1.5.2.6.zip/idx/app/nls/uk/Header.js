/*
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2012 All Rights Reserved
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define({      
//begin v1.x content
	ibmlogo: "IBM&reg;",
	actionShare: "Спільний доступ",
	actionSettings: "Параметри",
	actionHelp: "Довідка",
	searchEntry: "Пошук",
	searchSubmit: "Пошук",
	primarySearchLabelSuffix: "основний пошук",
	secondarySearchLabelSuffix: "допоміжний пошук",
	homeButton: "Домашня сторінка"
//end v1.x content
});

