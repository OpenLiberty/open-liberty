define({     
//begin v1.x content
	loginTitle: "Connexion",
	labelUserName: "Nom d'utilisateur",
	labelPassword: "Mot de passe",
	invalidMessageTitle: "Tentative de connexion non valide",
	invalidMessage: "Une valeur non valide a été entrée dans les deux zones obligatoires."
//end v1.x content
});

