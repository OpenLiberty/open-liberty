define({     
//begin v1.x content
	about:				"Tentang",
	help:			      "Bantuan",
	logout:				"Logout",
	login:				"Login",
	userNameMessage:  "Selamat datang ${username}"
//end v1.x content
});

