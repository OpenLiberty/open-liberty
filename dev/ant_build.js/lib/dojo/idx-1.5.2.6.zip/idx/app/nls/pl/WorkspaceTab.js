define({     
//begin v1.x content
   	altTitle: "Karta Obszar roboczy dla ${title}"
//end v1.x content
});

