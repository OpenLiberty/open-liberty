define({     
//begin v1.x content
	about:				"Acerca de",
	help:			      "Ajuda",
	logout:				"Terminar sessão",
	login:				"Iniciar sessão",
	userNameMessage:  "Bem-vindo ${username}"
//end v1.x content
});

