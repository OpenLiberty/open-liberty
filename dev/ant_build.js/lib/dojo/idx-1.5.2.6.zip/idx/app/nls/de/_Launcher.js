define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Es können maximal ${maxOpen} Arbeitsbereiche des Typs \"${workspaceTypeName}\"\u200e geöffnet werden. Falls möglich, schließen Sie Arbeitsbereiche des Typs \"${workspaceTypeName}\"\u200e."
//end v1.x content
});

