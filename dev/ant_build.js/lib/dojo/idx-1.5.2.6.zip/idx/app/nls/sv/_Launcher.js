define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Det går inte att öppna fler än ${maxOpen} \"${workspaceTypeName}\"\u200e-arbetsutrymmen. Stäng om möjligt \"${workspaceTypeName}\"\u200e-arbetsutrymmen som redan är öppna."
//end v1.x content
});

