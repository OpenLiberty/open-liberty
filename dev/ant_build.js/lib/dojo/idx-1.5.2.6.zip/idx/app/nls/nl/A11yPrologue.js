define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT plus ${accessKey}",
	keySequence_Firefox: "ALT plus SHIFT plus ${accessKey} onder Windows en Linux of CONTROL plus ${accessKey} op Mac",
	keySequence_Safari: "CONTROL plus OPT plus ${accessKey} op Mac of ALT plus ${accessKey} onder Windows",
	keySequence_Chrome: "ALT plus ${accessKey} onder Windows en Linux of CONTROL plus OPT plus ${accessKey} op Mac",
	shortcutListMessage: "De snelkoppelingen voor deze pagina zijn:",
	a11yPrologueLabel: "Proloog voor toegankelijkheid",
    a11yStatementLabel: "Verklaring van toegankelijkheid",
    skipToLocationMessage: "Meteen naar de ${description}",
	shortcutKeyMessage_internal: "Om meteen naar de ${description} te gaan, gebruikt u ${keySequence}.",
	shortcutKeyMessage_external: "Om door te gaan naar de ${description}, gebruikt u ${keySequence}.",
	shortcutMessage_internal: "Meteen naar de ${description}.",
	shortcutMessage_external: "Doorgaan naar de ${description}.",

	a11yMainContentAreaName: "hoofdinhoud",

	a11yNavigationAreaName: "navigatie",

	a11yBannerAreaName: "banner"
//end v1.x content
});

