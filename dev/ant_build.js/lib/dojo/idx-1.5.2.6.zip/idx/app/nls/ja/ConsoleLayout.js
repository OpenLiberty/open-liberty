define({     
//begin v1.x content
	about:				"情報",
	help:			      "ヘルプ",
	logout:				"ログアウト",
	login:				"ログイン",
	userNameMessage:  "ようこそ ${username} さん"
//end v1.x content
});

