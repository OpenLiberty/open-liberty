define({     
//begin v1.x content
   	altTitle: "Werkgebiedtab voor ${title}"
//end v1.x content
});

