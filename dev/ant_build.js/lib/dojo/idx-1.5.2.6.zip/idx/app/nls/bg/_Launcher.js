define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Не е възможно отварянето на повече от ${maxOpen} \"${workspaceTypeName}\"\u200e работни области. Ако е възможно, затворете \"${workspaceTypeName}\"\u200e работните области, които вече са отворени."
//end v1.x content
});

