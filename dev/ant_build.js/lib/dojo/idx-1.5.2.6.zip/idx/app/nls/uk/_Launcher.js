define({     
//begin v1.x content
    tooManyOpenWorkspaces: "Неможливо відкрити більше ${maxOpen} робочих областей \"${workspaceTypeName}\"\u200e.  Якщо це можливо, закрийте вже відкриті робочі області \"${workspaceTypeName}\"\u200e."
//end v1.x content
});

