define({     
//begin v1.x content
   	altTitle: "Tab vùng làm việc cho ${title}"
//end v1.x content
});

