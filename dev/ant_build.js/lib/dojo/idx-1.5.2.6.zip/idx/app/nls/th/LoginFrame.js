define({     
//begin v1.x content
	loginTitle: "ล็อกอิน",
	labelUserName: "ชื่อผู้ใช้",
	labelPassword: "รหัสผ่าน",
	invalidMessageTitle: "ความพยายามในการล็อกอินไม่ถูกต้อง",
	invalidMessage: "ไม่ได้ป้อนค่าที่ถูกต้องลงในทั้งสองฟิลด์ที่จำเป็น"
//end v1.x content
});

