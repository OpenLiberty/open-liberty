define({     
//begin v1.x content
    loadingMessage: "Zavádza sa ${workspaceTitle}.  Čakajte....",
    failedLoadMessage: "Nepodarilo sa zaviesť ${workspaceTitle}."
//end v1.x content
});

