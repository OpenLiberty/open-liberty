define({     
//begin v1.x content
   	altTitle: "Guia da Área de Trabalho para ${title}"
//end v1.x content
});

