define({     
//begin v1.x content
    tooManyOpenWorkspaces: "${maxOpen} 個を超える \"${workspaceTypeName}\"\u200e ワークスペースを開くことはできません。できるだけ、既に開いている \"${workspaceTypeName}\"\u200e ワークスペースを閉じてください。"
//end v1.x content
});

