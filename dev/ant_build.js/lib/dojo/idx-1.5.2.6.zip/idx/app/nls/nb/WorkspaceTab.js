define({     
//begin v1.x content
   	altTitle: "Arbeidsområdeflipp for ${title}"
//end v1.x content
});

