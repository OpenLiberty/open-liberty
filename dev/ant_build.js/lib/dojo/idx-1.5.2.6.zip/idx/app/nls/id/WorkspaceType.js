define({     
//begin v1.x content
    loadingMessage: "Memuat ${workspaceTitle}.  Harap tunggu....",
    failedLoadMessage: "Gagal memuat ${workspaceTitle}."
//end v1.x content
});

