define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT plus ${accessKey}",
	keySequence_Firefox: "ALT plus UMSCHALTTASTE plus ${accessKey} unter Windows und Linux oder STRG plus ${accessKey} beim Mac",
	keySequence_Safari: "STRG plus WAHLTASTE plus ${accessKey} beim Mac oder ALT plus ${accessKey} unter Windows",
	keySequence_Chrome: "ALT plus ${accessKey} unter Windows und Linux oder STRG plus WAHLTASTE plus ${accessKey} beim Mac",
	shortcutListMessage: "Direktaufrufe für diese Seite sind:",
	a11yPrologueLabel: "Behindertengerechte Bedienung - Prolog",
    a11yStatementLabel: "Erklärung zur behindertengerechten Bedienung",
    skipToLocationMessage: "Zu ${description} springen",
	shortcutKeyMessage_internal: "Zum Springen zu ${description} ${keySequence} verwenden",
	shortcutKeyMessage_external: "Zum Aufrufen des Links zu ${description} ${keySequence} verwenden",
	shortcutMessage_internal: "Zu ${description} springen",
	shortcutMessage_external: "Link zu ${description}",

	a11yMainContentAreaName: "Hauptinhalt",

	a11yNavigationAreaName: "Navigation",

	a11yBannerAreaName: "Banner"
//end v1.x content
});

