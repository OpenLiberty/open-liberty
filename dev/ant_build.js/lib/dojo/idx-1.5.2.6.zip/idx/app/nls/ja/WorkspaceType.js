define({     
//begin v1.x content
    loadingMessage: "${workspaceTitle} をロードしています。  お待ちください....",
    failedLoadMessage: "${workspaceTitle} のロードに失敗しました。"
//end v1.x content
});

