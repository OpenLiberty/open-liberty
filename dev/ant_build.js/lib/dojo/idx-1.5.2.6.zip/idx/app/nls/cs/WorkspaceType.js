define({     
//begin v1.x content
    loadingMessage: "Probíhá načítání pracovního prostoru ${workspaceTitle}. Čekejte, prosím...",
    failedLoadMessage: "Pracovní prostor ${workspaceTitle} se nepodařilo načíst."
//end v1.x content
});

