define({     
//begin v1.x content
   	altTitle: "${title}에 대한 작업영역 탭"
//end v1.x content
});

