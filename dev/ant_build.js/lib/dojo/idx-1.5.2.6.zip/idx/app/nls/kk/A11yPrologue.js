define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT және ${accessKey} пернелері",
	keySequence_Firefox: "ALT және SHIFT ${accessKey} пернелерін Windows терезесіне және Linux немесе CONTROL ${accessKey} пернелерін Mac пернесіне",
	keySequence_Safari: "CONTROL және OPT ${accessKey} пернелерін Mac немесе ALT және ${accessKey} пернелерін Windows терезесіне",
	keySequence_Chrome: "ALT және ${accessKey} пернелерін Windows және Linux немесе CONTROL және OPT және ${accessKey} пернелерін Mac пернелеріне",
	shortcutListMessage: "Мына бетке арналған лақаптар:",
	a11yPrologueLabel: "Арнайы мүмкіндіктер прологы",
    a11yStatementLabel: "Арнайы мүмкіндіктер нұсқауы",
    skipToLocationMessage: "Параметріне өткізіп жіберіңіз ${description}",
	shortcutKeyMessage_internal: "${description} бетіне өту үшін, ${keySequence} пайдаланыңыз.",
	shortcutKeyMessage_external: "${description} бетімен байланысу үшін, ${keySequence} пайдаланыңыз.",
	shortcutMessage_internal: "${description} бетіне өтіңіз.",
	shortcutMessage_external: "${description} бетімен байланысыңыз.",

	a11yMainContentAreaName: "басты мазмұн",

	a11yNavigationAreaName: "шарлау",

	a11yBannerAreaName: "жариялама"
//end v1.x content
});

