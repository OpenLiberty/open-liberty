define({     
//begin v1.x content
	keySequence_InternetExplorer: "ALT plus ${accessKey}",
	keySequence_Firefox: "ALT plus SHIFT plus ${accessKey} w systemie Windows i Linux lub CONTROL plus ${accessKey} w systemie Mac",
	keySequence_Safari: "CONTROL plus OPT plus ${accessKey} w systemie Mac lub ALT plus ${accessKey} w systemie Windows",
	keySequence_Chrome: "ALT plus ${accessKey} w systemach Windows i Linux albo CONTROL plus OPT plus ${accessKey} w systemie Mac",
	shortcutListMessage: "Skróty dostępu do tej strony są następujące:",
	a11yPrologueLabel: "Prologu na temat ułatwień dostępu",
    a11yStatementLabel: "Oświadczenia dotyczącego ułatwień dostępu",
    skipToLocationMessage: "Pomiń i przejdź do ${description}",
	shortcutKeyMessage_internal: "Aby pominąć i przejść do ${description}, użyj ${keySequence}.",
	shortcutKeyMessage_external: "Aby przejść do ${description}, użyj ${keySequence}.",
	shortcutMessage_internal: "Pomiń i przejdź do: ${description}.",
	shortcutMessage_external: "Przejdź do: ${description}.",

	a11yMainContentAreaName: "głównej treści",

	a11yNavigationAreaName: "nawigacji",

	a11yBannerAreaName: "banera"
//end v1.x content
});
