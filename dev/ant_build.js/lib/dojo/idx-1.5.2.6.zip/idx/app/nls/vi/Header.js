/*
 * Licensed Materials - Property of IBM
 * (C) Copyright IBM Corp. 2010, 2012 All Rights Reserved
 * US Government Users Restricted Rights - Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */

define({      
//begin v1.x content
	ibmlogo: "IBM&reg;",
	actionShare: "Chia sẻ",
	actionSettings: "Cài đặt",
	actionHelp: "Trợ giúp",
	searchEntry: "Tìm kiếm",
	searchSubmit: "Tìm kiếm",
	primarySearchLabelSuffix: "tìm kiếm chính",
	secondarySearchLabelSuffix: "tìm kiếm phụ",
	homeButton: "Trang chủ"
//end v1.x content
});

